The icons used in this plugin are made available to you according to the following conditions.

| File         | License/Origin                                                                   |
| ------------ | -------------------------------------------------------------------------------- |
| monologo.svg | Proprietary Collabora Ltd, see https://www.collaboraoffice.com/trademark-policy/ |
| monologo.png | as above                                                                         |
| odp.svg      | https://cgit.freedesktop.org/libreoffice/core/tree/icon-themes/breeze_svg        |
| ods.svg      | https://cgit.freedesktop.org/libreoffice/core/tree/icon-themes/breeze_svg        |
| odt.svg      | https://cgit.freedesktop.org/libreoffice/core/tree/icon-themes/breeze_svg        |
