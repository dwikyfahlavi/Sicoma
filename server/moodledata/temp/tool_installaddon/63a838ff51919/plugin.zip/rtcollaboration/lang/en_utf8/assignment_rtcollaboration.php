<?php
    
    $string['typertcollaboration'] = 'Collaborative real-time editor';
	$string['charsadded'] = 'Chars added: ';
	$string['charsdeleted'] = 'Chars deleted: ';
	$string['userhasnotparticipate'] = 'This user has not participated.';
	$string['overview'] = 'overview';
	$string['textstatistics'] = 'Text statistics';
	$string['reviewtextedition'] = 'Review text edition';
	$string['firstedited'] = 'First edited: ';
	$string['lastedited'] = 'Last edited: ';
	$string['currentlyviewing'] = 'Currently viewing: ';
	$string['submitedtext'] = 'Submited text for evaluation';
	$string['currenttext'] = 'Current text';
	$string['viewusersactivity'] = 'View users activity';
	$string['noinfo'] = 'There is no data for the selected group';
    $string['chooseyourgroup'] = 'Choose your group';
	$string['onlyviewpermissions'] = 'You have only view permissions on this group text';
    $string['typeofeditor'] = 'Type of editor';
    $string['plaintext'] = 'Plain Text';
    $string['yui'] = 'YUI Rich Text Editor';
    
	$string[''] = '';
?>