rtcollaboration is a new type of assignment. It's a collaborative real-time editor that works like Google Docs (in plain text, I'm working in the rich text editor feature..)
Two or more users can work at the same time in the same document. When you type a word the text is updated in real-time for the other users
Groups are supported but are not very well tested in this beta version

Teachers can review their students job, for every student the total account of chars added or deleted by him in the text is displayed in the submissions view of the assignment0
Teachers can "replay" the users interactions with the editor. Highlighting is not supported ye

Working with groups

Groups are supported in this way:

Possible course or activity groups configurations when groups are enabled:

If the user is member of more than a group is linked to him first group text
If the user is not member of any group is linked to the group 0 text

Visible groups
User:
When the groups are visible, a user can view all the current texts being edited by any user in any group in the course
Teacher:
The teacher can view and review all the groups and users text

Separate groups
User:
The user can view only his group text

Teacher:
If the teacher has the capability accessallgroups:
The teacher can view all the groups texts

If not:
The teacher can view only his group/s text