<?php

    $plugin->version  = 2011092201;
    // Moodle version required
    $plugin->requires = 2010112400;
    $plugin->maturity = MATURITY_STABLE;
    $plugin->release = 1.0;   
